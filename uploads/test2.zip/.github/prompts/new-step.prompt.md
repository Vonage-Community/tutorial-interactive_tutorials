---
mode: agent
description: Create a new tutorial step file with the correct naming, frontmatter, and structure.
---

Create a new tutorial step for this Vonage interactive tutorial.

Follow the structure shown in `#file:../src/content/docs/02-step-template.md` and the
naming and formatting rules in `#file:.github/copilot-instructions.md`.

Ask the user for the following information (one at a time if needed):

1. **Step number** — What number should this step be? (e.g. `03`)
2. **Step name** — A short kebab-case name for the URL and filename (e.g. `initialize-client`)
3. **Step title** — A short human-readable title for the sidebar (e.g. `Initialize the Client`)
4. **Description** — What does the user do in this step? What will they accomplish?
5. **Code** — Is there any code or terminal command the user needs to run or copy? If so, what language?
6. **Components** — Should this step use any Markdoc components (aside/tip/caution, filetree, steps, tabs)?

Then create the file `src/content/docs/NN-step-name.md` (with the actual number and name filled in)
following these rules:

- Frontmatter with `title:` (required) and `description:` (if provided)
- H1 heading matching or elaborating on the title
- 1–3 sentence intro paragraph explaining what the user will do and why
- Fenced code blocks with the correct language identifier for all code/commands
- Appropriate Markdoc components based on the content
- 1–2 sentence closing summary of what was accomplished (unless this is the last step)

Do not modify any existing files. Only create the new step file.
