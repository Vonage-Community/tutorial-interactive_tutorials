---
title: Create a Vonage Account
description: Create a Vonage account.
---

First, a Vonage account is needed to get the credentials to set up this workshop application. You can sign up for your account here: <a href="https://vonage.dev/StrangerBuildsHack" target="_blank">event page</a>

Here's a coupon to add money to your <a href="https://dashboard.vonage.com/coupons" target="_blank">account</a>:

```html
10VSBNC26
```

> Note: Make sure to copy your API Key and API Secret somewhere. We will need it in the next step.
