# Vonage toolbar application for authoring tutorials

In the preview, there will be a toolbar in the bottom middle of the page.
Click the Vonage logo for the instructions.

![Screenshot of toolbar app. A dark gray rectangular interface element with rounded corners, displaying a list of six steps in white text, each preceded by a right-pointing triangle. Below the rectangle is a smaller dark gray rounded rectangle containing five white icons: an Astro logo, cursor arrow, three horizontal lines with a magnification glass, a V, and a gear icon. ](./toolbar.png)
