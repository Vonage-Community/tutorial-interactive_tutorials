# Astro Dev Toolbar application for Vonage Onboarding Tutorials

[![Open in StackBlitz](https://developer.stackblitz.com/img/open_in_stackblitz.svg)](https://stackblitz.com/fork/github/Vonage-Community/tutorial-interactive_tutorials/tree/main/toolbar-app/)

or if working locally, run `npm install && npm run dev`

For more information on the Astro Dev Toolbar, please see their [documentation](https://docs.astro.build/en/guides/dev-toolbar/)

[![Built with Starlight](https://astro.badg.es/v2/built-with-starlight/tiny.svg)](https://starlight.astro.build)
