---
title: Second Step
description: An introduction to the onboarding tutorial
---

# Starter Tutorial

Stuff

Paste this into customer.js

```js
function demo() {
  // This is a comment
  console.log('Hello World');
}
```
