---
title: Second Step
description: An introduction to the onboarding tutorial
---

# Step 2

This is step 2!

Here is some code:

```js
function demo() {
  // This is a comment
  console.log('Hello World');
}
```
